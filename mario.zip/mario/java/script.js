const personagem = document.getElementById("mario");
const obstaculo = document.getElementById("cano");
const nuvem = document.getElementById("nuvens");

const tema = document.getElementById("tema");
const pulo = document.getElementById("pulo");
const gameover = document.getElementById("gameover");

const pontuacao = document.getElementById("pontuacao");

const display = document.getElementById("display");

document.addEventListener("keydown", inicia_musica);

function inicia_musica() {
  tema.play();
  document.removeEventListener("keydown", inicia_musica);
}

document.addEventListener("keydown", jump);
function jump() {
  personagem.classList.add("jump");
  setTimeout(jumpout, 500);
}

function jumpout() {
  personagem.classList.remove("jump");
}

const loop = setInterval(verifica, 10);

function verifica() {
  const posicaoAtualobstaculo = obstaculo.offsetLeft;
  const posicaoAtualPersonagem = +getComputedStyle(personagem).bottom.replace(
    "px",
    ""
  );
  const posicaoAtualNuvem = nuvem.offsetLeft;

  if (
    posicaoAtualobstaculo < 100 &&
    posicaoAtualobstaculo > 0 &&
    posicaoAtualPersonagem < 75
  ) {
    //colisão Game Over
    // Parar a nuvem
    nuvem.style.animation = "none";
    nuvem.style.left = posicaoAtualNuvem + "px";

    // Parar o objstaculo
    obstaculo.style.animation = "none";
    obstaculo.style.left = posicaoAtualobstaculo + "px";

    // Parar o loop
    clearInterval(loop);
    // Trocar o personagem
    personagem.style.animation = "none";
    personagem.style.bottom = posicaoAtualPersonagem + "px";
    personagem.src = "./images/game-over.png";
    personagem.style.width = "50px";
    // Para a musica tema
    tema.pause();
    // Tocar a musica de game-over
    gameover.play();
    // Escrever Game-Over na tela
    display.innerHTML = "<h3>Game Over</h3>";
  } else {
    pontuacao.textContent = +pontuacao.textContent + 0.5;
  }
}

function restart() {
  location.reload();
}
